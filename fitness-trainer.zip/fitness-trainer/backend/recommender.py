"""
recommender.py — Personalized workout recommendation engine
Adapts difficulty and exercise selection based on user session history.
"""

from collections import defaultdict

WORKOUT_PROGRESSIONS = {
    "squat":      {"next": "lunge",       "threshold_reps": 20},
    "pushup":     {"next": "plank",       "threshold_reps": 15},
    "bicep_curl": {"next": "pushup",      "threshold_reps": 12},
    "lunge":      {"next": "jumping_jack","threshold_reps": 15},
    "plank":      {"next": "squat",       "threshold_reps": 1},
    "jumping_jack":{"next": "lunge",      "threshold_reps": 30},
}

BEGINNER_PLAN = ["jumping_jack", "squat", "pushup"]
INTERMEDIATE_PLAN = ["squat", "lunge", "pushup", "plank"]
ADVANCED_PLAN = ["squat", "lunge", "pushup", "bicep_curl", "plank", "jumping_jack"]


def get_recommendations(history):
    """
    Analyzes session history and returns recommended workouts with target reps.
    """
    if not history:
        return [{"workout": w, "target_reps": 10, "reason": "Great starting workout!"} for w in BEGINNER_PLAN]

    # Aggregate stats per workout
    stats = defaultdict(lambda: {"total_reps": 0, "sessions": 0, "avg_reps": 0})
    for session in history:
        wid = session.get("workout")
        reps = session.get("reps", 0)
        if wid:
            stats[wid]["total_reps"] += reps
            stats[wid]["sessions"] += 1

    for wid, s in stats.items():
        s["avg_reps"] = round(s["total_reps"] / max(s["sessions"], 1))

    recommendations = []
    for wid, s in stats.items():
        prog = WORKOUT_PROGRESSIONS.get(wid, {})
        avg = s["avg_reps"]
        threshold = prog.get("threshold_reps", 15)

        if avg >= threshold and prog.get("next"):
            next_w = prog["next"]
            recommendations.append({
                "workout": next_w,
                "target_reps": threshold + 5,
                "reason": f"You've mastered {wid}! Time to try {next_w}.",
            })
        else:
            recommendations.append({
                "workout": wid,
                "target_reps": avg + 3,
                "reason": f"Keep pushing — aim for {avg + 3} reps!",
            })

    return recommendations[:3]  # Return top 3
