"""
app.py — Optional Flask backend for personalized workout recommendations
Run: python backend/app.py
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from recommender import get_recommendations

app = Flask(__name__)
CORS(app)

@app.route("/api/recommend", methods=["POST"])
def recommend():
    data = request.get_json()
    history = data.get("history", [])
    recommendations = get_recommendations(history)
    return jsonify({"recommendations": recommendations})

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "FitAI Recommendation Engine"})

if __name__ == "__main__":
    app.run(debug=True, port=5001)
