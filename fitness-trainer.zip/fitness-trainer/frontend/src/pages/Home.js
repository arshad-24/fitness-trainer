import React from "react";
import { useNavigate } from "react-router-dom";
import { WORKOUT_LIST } from "../utils/workouts";

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="home-page">
      <div className="hero">
        <h1>🏋️ FitAI</h1>
        <p>Your AI-powered personal trainer. Real-time pose correction, rep counting, and personalized workouts.</p>
      </div>

      <h2>Choose Your Workout</h2>
      <div className="workout-grid">
        {WORKOUT_LIST.map((workout) => (
          <div
            key={workout.id}
            className="workout-card"
            onClick={() => navigate(`/session/${workout.id}`)}
          >
            <div className="workout-emoji">{workout.emoji}</div>
            <h3>{workout.name}</h3>
            <p>{workout.description}</p>
            <button className="btn-start">Start →</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
