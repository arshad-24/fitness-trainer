import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PoseCamera from "../components/PoseCamera";
import { WORKOUTS } from "../utils/workouts";

const WorkoutSession = () => {
  const { workoutId } = useParams();
  const navigate = useNavigate();
  const workout = WORKOUTS[workoutId];
  const [reps, setReps] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    if (!isActive) return;
    const timer = setInterval(() => setElapsed((s) => s + 1), 1000);
    return () => clearInterval(timer);
  }, [isActive]);

  const formatTime = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const handleFinish = () => {
    setIsActive(false);
    // Save session to localStorage
    const history = JSON.parse(localStorage.getItem("fitai_history") || "[]");
    history.push({ workout: workoutId, reps, duration: elapsed, date: new Date().toISOString() });
    localStorage.setItem("fitai_history", JSON.stringify(history));
    navigate("/progress");
  };

  if (!workout) return <div>Workout not found.</div>;

  return (
    <div className="session-page">
      <div className="session-header">
        <button onClick={() => navigate("/")} className="btn-back">← Back</button>
        <h2>{workout.emoji} {workout.name}</h2>
        <div className="timer">{formatTime(elapsed)}</div>
      </div>

      <div className="session-layout">
        <PoseCamera workout={workout} onRepsUpdate={setReps} />
        <div className="session-stats">
          <div className="stat-card">
            <div className="stat-value">{reps}</div>
            <div className="stat-label">Reps</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{formatTime(elapsed)}</div>
            <div className="stat-label">Duration</div>
          </div>
          <div className="instructions">
            <h4>Form Tips</h4>
            <p>{workout.description}</p>
          </div>
          <button onClick={handleFinish} className="btn-finish">Finish Workout</button>
        </div>
      </div>
    </div>
  );
};

export default WorkoutSession;
