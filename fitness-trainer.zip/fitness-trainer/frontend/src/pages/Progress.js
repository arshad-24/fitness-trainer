import React, { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { WORKOUTS } from "../utils/workouts";

const Progress = () => {
  const history = useMemo(() => {
    return JSON.parse(localStorage.getItem("fitai_history") || "[]").reverse();
  }, []);

  const chartData = history.map((s, i) => ({
    session: `#${history.length - i}`,
    reps: s.reps,
    duration: Math.round(s.duration / 60),
  })).reverse();

  const totalReps = history.reduce((sum, s) => sum + s.reps, 0);
  const totalSessions = history.length;

  return (
    <div className="progress-page">
      <h1>📊 Your Progress</h1>

      <div className="stats-row">
        <div className="stat-card"><div className="stat-value">{totalSessions}</div><div className="stat-label">Sessions</div></div>
        <div className="stat-card"><div className="stat-value">{totalReps}</div><div className="stat-label">Total Reps</div></div>
      </div>

      {chartData.length > 1 && (
        <div className="chart-container">
          <h3>Reps Per Session</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="session" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="reps" stroke="#00ff88" strokeWidth={2} dot={{ fill: "#00ff88" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <h3>Session History</h3>
      <div className="history-list">
        {history.length === 0 ? (
          <p>No sessions yet. Start your first workout!</p>
        ) : (
          history.map((s, i) => (
            <div key={i} className="history-item">
              <span className="workout-emoji">{WORKOUTS[s.workout]?.emoji}</span>
              <div>
                <strong>{WORKOUTS[s.workout]?.name}</strong>
                <p>{new Date(s.date).toLocaleDateString()} — {s.reps} reps in {Math.round(s.duration / 60)}m</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Progress;
