import { useRef, useState, useCallback } from "react";
import { calculateAngle, getKeypoint } from "../utils/poseUtils";

/**
 * useRepCounter — angle-based rep detection for exercises
 * @param {object} workout - workout config with joints and repThresholds
 */
const useRepCounter = (workout) => {
  const [reps, setReps] = useState(0);
  const [feedback, setFeedback] = useState("");
  const stageRef = useRef("up"); // 'up' or 'down'

  const processFrame = useCallback(
    (pose) => {
      if (!pose || !workout || workout.type === "hold") return;

      const { joints, repThresholds } = workout;
      const [jointA, jointB, jointC] = joints;

      const A = getKeypoint(pose, jointA);
      const B = getKeypoint(pose, jointB);
      const C = getKeypoint(pose, jointC);

      if (!A || !B || !C) return;

      const angle = calculateAngle(A, B, C);

      // State machine: up → down → up = 1 rep
      if (angle < repThresholds.down) {
        stageRef.current = "down";
        setFeedback(workout.feedback?.good || "Good!");
      }
      if (angle > repThresholds.up && stageRef.current === "down") {
        stageRef.current = "up";
        setReps((prev) => prev + 1);
      }
    },
    [workout]
  );

  const reset = () => {
    setReps(0);
    setFeedback("");
    stageRef.current = "up";
  };

  return { reps, feedback, processFrame, reset };
};

export default useRepCounter;
