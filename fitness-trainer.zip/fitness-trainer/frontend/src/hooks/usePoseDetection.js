import { useEffect, useRef, useState } from "react";
import * as poseDetection from "@tensorflow-models/pose-detection";
import "@tensorflow/tfjs-backend-webgl";

const usePoseDetection = (videoRef) => {
  const [pose, setPose] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const detectorRef = useRef(null);
  const rafRef = useRef(null);

  useEffect(() => {
    const initDetector = async () => {
      try {
        const detector = await poseDetection.createDetector(
          poseDetection.SupportedModels.MoveNet,
          {
            modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
          }
        );
        detectorRef.current = detector;
        setIsLoading(false);
      } catch (err) {
        console.error("Failed to load pose detector:", err);
        setIsLoading(false);
      }
    };

    initDetector();

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  useEffect(() => {
    if (isLoading || !detectorRef.current) return;

    const detect = async () => {
      const video = videoRef.current;
      if (video && video.readyState >= 2) {
        try {
          const poses = await detectorRef.current.estimatePoses(video);
          if (poses.length > 0) setPose(poses[0]);
        } catch (err) {
          // Silently skip frames on error
        }
      }
      rafRef.current = requestAnimationFrame(detect);
    };

    rafRef.current = requestAnimationFrame(detect);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [isLoading, videoRef]);

  return { pose, isLoading };
};

export default usePoseDetection;
