// Workout definitions — joints to track and rep detection config

export const WORKOUTS = {
  squat: {
    name: "Squat",
    emoji: "🏋️",
    description: "Feet shoulder-width apart, lower until thighs are parallel",
    joints: ["left_hip", "left_knee", "left_ankle"],
    repThresholds: { down: 90, up: 160 },  // knee angle degrees
    feedback: {
      tooHigh: "Go lower — aim for parallel thighs",
      tooWide: "Keep knees over toes",
      good: "Perfect depth!",
    },
  },
  pushup: {
    name: "Push-up",
    emoji: "💪",
    description: "Lower chest to ground, keep core tight",
    joints: ["left_shoulder", "left_elbow", "left_wrist"],
    repThresholds: { down: 80, up: 160 },  // elbow angle
    feedback: {
      tooHigh: "Lower your chest closer to the ground",
      hipSag: "Keep your core engaged — hips too low",
      good: "Great form!",
    },
  },
  bicep_curl: {
    name: "Bicep Curl",
    emoji: "🦾",
    description: "Keep elbows at your sides, curl fully",
    joints: ["left_shoulder", "left_elbow", "left_wrist"],
    repThresholds: { down: 160, up: 50 },
    feedback: {
      swinging: "Don't swing — keep elbows stationary",
      good: "Full range of motion!",
    },
  },
  lunge: {
    name: "Lunge",
    emoji: "🦵",
    description: "Step forward, lower back knee toward floor",
    joints: ["left_hip", "left_knee", "left_ankle"],
    repThresholds: { down: 90, up: 170 },
    feedback: {
      tooShallow: "Step further forward for full lunge",
      good: "Great depth!",
    },
  },
  plank: {
    name: "Plank",
    emoji: "🧱",
    description: "Keep body straight from head to heels",
    type: "hold",
    holdDuration: 30, // seconds
    feedback: {
      hipTooHigh: "Lower your hips",
      hipTooLow: "Raise your hips — keep body straight",
      good: "Body is aligned — hold it!",
    },
  },
  jumping_jack: {
    name: "Jumping Jack",
    emoji: "⭐",
    description: "Jump feet out and raise arms overhead simultaneously",
    joints: ["left_shoulder", "right_shoulder", "left_hip"],
    repThresholds: { open: 0.3, closed: 0.1 }, // wrist Y relative
    feedback: {
      good: "Good rhythm!",
    },
  },
};

export const WORKOUT_LIST = Object.entries(WORKOUTS).map(([key, val]) => ({
  id: key,
  ...val,
}));
