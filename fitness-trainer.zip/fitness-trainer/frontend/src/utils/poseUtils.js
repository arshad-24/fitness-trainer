/**
 * poseUtils.js — Math helpers for pose analysis
 */

/**
 * Calculate angle (degrees) at joint B given points A, B, C
 */
export const calculateAngle = (A, B, C) => {
  const radians =
    Math.atan2(C.y - B.y, C.x - B.x) - Math.atan2(A.y - B.y, A.x - B.x);
  let angle = Math.abs((radians * 180.0) / Math.PI);
  if (angle > 180.0) angle = 360 - angle;
  return angle;
};

/**
 * Get a keypoint object {x, y, score} by name from a pose
 */
export const getKeypoint = (pose, name) => {
  const kp = pose?.keypoints?.find((k) => k.name === name);
  return kp && kp.score > 0.3 ? { x: kp.x, y: kp.y, score: kp.score } : null;
};

/**
 * Check if all required keypoints are visible
 */
export const keypointsVisible = (pose, names) =>
  names.every((name) => getKeypoint(pose, name) !== null);

/**
 * Map COCO keypoint indices to names (MoveNet uses named keypoints)
 */
export const KEYPOINT_NAMES = [
  "nose", "left_eye", "right_eye", "left_ear", "right_ear",
  "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
  "left_wrist", "right_wrist", "left_hip", "right_hip",
  "left_knee", "right_knee", "left_ankle", "right_ankle",
];

/**
 * Skeleton connections for drawing
 */
export const SKELETON_CONNECTIONS = [
  ["left_shoulder", "right_shoulder"],
  ["left_shoulder", "left_elbow"],
  ["left_elbow", "left_wrist"],
  ["right_shoulder", "right_elbow"],
  ["right_elbow", "right_wrist"],
  ["left_shoulder", "left_hip"],
  ["right_shoulder", "right_hip"],
  ["left_hip", "right_hip"],
  ["left_hip", "left_knee"],
  ["left_knee", "left_ankle"],
  ["right_hip", "right_knee"],
  ["right_knee", "right_ankle"],
];
