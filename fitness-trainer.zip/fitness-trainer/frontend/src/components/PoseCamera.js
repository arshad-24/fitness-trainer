import React, { useRef, useEffect } from "react";
import usePoseDetection from "../hooks/usePoseDetection";
import useRepCounter from "../hooks/useRepCounter";
import { SKELETON_CONNECTIONS, getKeypoint } from "../utils/poseUtils";

const PoseCamera = ({ workout, onRepsUpdate }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const { pose, isLoading } = usePoseDetection(videoRef);
  const { reps, feedback, processFrame } = useRepCounter(workout);

  // Start webcam
  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480 },
        });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {
        console.error("Camera access denied:", err);
      }
    };
    startCamera();
    return () => {
      if (videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  // Process pose and draw skeleton
  useEffect(() => {
    if (!pose) return;
    processFrame(pose);
    onRepsUpdate?.(reps);
    drawSkeleton(pose);
  }, [pose]);

  const drawSkeleton = (pose) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    const ctx = canvas.getContext("2d");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw connections
    ctx.strokeStyle = "#00ff88";
    ctx.lineWidth = 3;
    SKELETON_CONNECTIONS.forEach(([a, b]) => {
      const ptA = getKeypoint(pose, a);
      const ptB = getKeypoint(pose, b);
      if (ptA && ptB) {
        ctx.beginPath();
        ctx.moveTo(ptA.x, ptA.y);
        ctx.lineTo(ptB.x, ptB.y);
        ctx.stroke();
      }
    });

    // Draw keypoints
    pose.keypoints.forEach((kp) => {
      if (kp.score > 0.3) {
        ctx.beginPath();
        ctx.arc(kp.x, kp.y, 5, 0, 2 * Math.PI);
        ctx.fillStyle = "#ff4444";
        ctx.fill();
      }
    });
  };

  return (
    <div className="pose-camera-wrapper">
      {isLoading && <div className="loading-overlay">Loading AI Model...</div>}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="camera-feed"
      />
      <canvas ref={canvasRef} className="skeleton-overlay" />
      <div className="rep-display">
        <span className="rep-count">{reps}</span>
        <span className="rep-label">REPS</span>
      </div>
      {feedback && <div className="feedback-banner">{feedback}</div>}
    </div>
  );
};

export default PoseCamera;
