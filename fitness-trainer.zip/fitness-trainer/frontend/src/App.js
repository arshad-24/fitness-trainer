import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import WorkoutSession from "./pages/WorkoutSession";
import Progress from "./pages/Progress";
import "./App.css";

function App() {
  return (
    <Router>
      <nav className="navbar">
        <a href="/" className="logo">🏋️ FitAI</a>
        <a href="/progress">Progress</a>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/session/:workoutId" element={<WorkoutSession />} />
        <Route path="/progress" element={<Progress />} />
      </Routes>
    </Router>
  );
}

export default App;
