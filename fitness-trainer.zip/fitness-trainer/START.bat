@echo off
title FitAI - Setup and Run
color 0D

echo.
echo  ==========================================
echo    FITAI - AI Personal Fitness Trainer
echo  ==========================================
echo.

:: ---- Check Node.js ----
node -v >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is NOT installed.
    echo Please download from: https://nodejs.org
    pause
    exit
)
echo [OK] Node.js found

:: ---- Install frontend packages ----
echo.
echo [STEP] Installing packages (2-3 minutes)...
cd frontend
call npm install
echo [OK] Packages installed

:: ---- Start app ----
echo.
echo [STEP] Starting FitAI...
echo Browser will open at http://localhost:3000
echo Allow camera access when browser asks!
echo.
start "FitAI" cmd /k "npm start"
cd ..

echo.
echo  ==========================================
echo   FitAI is starting in your browser!
echo   Allow CAMERA ACCESS when prompted.
echo   Keep the black window open.
echo  ==========================================
echo.
pause
