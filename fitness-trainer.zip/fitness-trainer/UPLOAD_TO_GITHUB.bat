@echo off
title Upload to GitHub
color 0E

echo.
echo  ==========================================
echo    UPLOAD FitAI to GitHub
echo  ==========================================
echo.

git --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Git is not installed. Download from: https://git-scm.com
    pause
    exit
)

echo Enter your GitHub details:
echo.
set /p USERNAME=Your GitHub username: 
set /p EMAIL=Your GitHub email: 
set /p REPONAME=Repository name (e.g. fitai-personal-trainer): 

git config --global user.name "%USERNAME%"
git config --global user.email "%EMAIL%"

git init
git add .
git commit -m "Initial commit: FitAI AI-powered fitness trainer with pose estimation"
git branch -M main
git remote add origin https://github.com/%USERNAME%/%REPONAME%.git
git push -u origin main

echo.
echo  ==========================================
echo   SUCCESS! Visit:
echo   https://github.com/%USERNAME%/%REPONAME%
echo  ==========================================
echo.
pause
